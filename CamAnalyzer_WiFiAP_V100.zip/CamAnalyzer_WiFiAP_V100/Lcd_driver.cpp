/**
 * @file    Lcd_driver.cpp
 * @brief   i2c LCD初期化と表示(LCD描画（メイン画面・設定画面）)
 * @author  yoshio ide
 * @date    2026-05-01
 * 
 * [作成履歴 / Update History]
 * 2026/04/19 - 新規作成 (v1.0.0)
 * 2026/04/19 - 初期化と表示。(v1.1.0)
 * 
 * 
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#include "Lcd_driver.h"
#include <Arduino.h>


// lcdの実体を定義
LiquidCrystal_I2C lcd(0x27, 20, 4);

// ∞（無限大）を登録パタ－ン
byte infinityChar[8] = {
  0b00000, // ........
  0b01010, // . # . # .
  0b10101, // # . # . #
  0b10101, // # . # . #
  0b01010, // . # . # .
  0b00000, // ........
  0b00000, // ........
  0b00000  // ........
};

// 角度 シータθ
// (θ)のドットパターン（カスタム文字）を定義
byte theta[8] = {
  B00000,
  B01110,
  B10001,
  B10001,
  B11111,
  B10001,
  B01110,
  B00000
};


void init_lcd() {
    lcd.init();
    lcd.backlight();

    // 0番に無限大のパターンを登録
    lcd.createChar(0, infinityChar);    // 未使用 lcd.write(0);←で無限大表示

    // 1番にθシータのパターンを登録
    lcd.createChar(1, theta);    // 未使用 lcd.write(1);←でθシータ表示

    lcd.clear();

}

/* ****************************************************
 * メイン画面の描画(仮想ウィンドウ（スクロール）構造)
 * 1.RPM （エンジン回転数）
 * 2.Angle （現在のカム角）
 * 3.Linear (2006/05/23 ADD) 小野測器
 * 4.Lift -（1mm リフト量 ※マイナスする値）
 * 5.BTDC （IO）吸気オープン
 * 6.ABDC （IC）吸気クローズ
 * 7.BBDC  (E0)
 * 8 ATDC   (Ec)
 * 7.Dure.IN （吸気カム作用角 / カムデュレーション）LIFT -
 * 8.Dura.EX （排気カム作用角 / カムデュレーション）LIFT -
 * 9.Overlap
 * 10 Lob Cen  (計算値)
 * 11 Max Lift (実測値)
 *
 * ラベル部分を「左詰め・7文字分」の幅で固定し、その直後に = を配置
 * 8列目での「＝」縦揃え %-7s= 
 *******************************************************/

/******* display_main_screen *********
 * 完全自動レイアウト
 *  ラベルの最大文字数を自動検出 (ラベルの後ろに空白を2つ追加 )
 *  ＝の位置を自動決定
 *  値の開始位置も自動決定
 *  全体が 20 文字以内に収まるように自動調整
 *  Linear / Lift の “mm” も自動で付加
 **************************************/
void display_main_screen(int offset,
                         const char* labels[],
                         char values[][16]) {

    // 1. ラベル最大長を自動計算
    int max_label_len = 0;
    for (int i = 0; i < 17; i++) {
        int len = strlen(labels[i]);
        if (len > max_label_len) max_label_len = len;
    }

    // ラベル幅の上限（LCD 左側が崩れないように）
    if (max_label_len > 12) max_label_len = 12;  // 12文字まで許可

    // 2. 値の幅を計算（20桁に収める）
    // [label][space][space][=][value]
    int value_width = 20 - (max_label_len + 1);  // "=" の1文字だけ

    if (value_width < 4) value_width = 4;  // 最低4桁は確保

    for (int i = 0; i < 4; i++) {
        int idx = i + offset;

        lcd.setCursor(0, i);

        if (idx < 0 || idx >= 17) {
            lcd.print("                    ");
            continue;
        }

        // ラベル整形
        char label_clean[20] = {0};
        strncpy(label_clean, labels[idx], max_label_len);

        for (int j = 0; j < max_label_len; j++) {
            if (label_clean[j] == '=') label_clean[j] = ' ';
        }

        // 値整形
        char value_buf[16];

        if (idx == 2 || idx == 3 || idx == 13 || idx == 16) {
            snprintf(value_buf, sizeof(value_buf), "%s mm", values[idx]);


        } else {
            snprintf(value_buf, sizeof(value_buf), "%s", values[idx]);
        }

        // 3. 完全自動レイアウト（＝を右に1つずらし("%-*s =%-*s",)、"%-*sこのブランク=%-*s",直後に値）→　20260624　ブランクは入れない
        char buf[25];
        snprintf(buf, sizeof(buf),
                 "%-*s=%-*s",
                 max_label_len, label_clean,
                 value_width, value_buf);

        lcd.print(buf);
    }
}

 /******設定画面の描画 (MODE, Range,,,) ********
 * [1]  cur_mark ('>' or ' ')
 * [8]  label（8文字固定）
 * [1]  space
 * [1]  ':' コロン
 * [8]  opt（値、最大8文字）
 * [1]  mark ('*' or ' ')
 * 合計 20文字
 *********************************************/
void display_setting_screen(int cursor, int mode, MenuEntry* menu) {

    for (int i = 0; i < 4; i++) {

        int idx = (cursor / 4 * 4) + i; 
        lcd.setCursor(0, i);

        if (idx < MENU_COUNT) {

            char buf[22]; // 20桁＋余裕

            // -----------------------------
            // ① 現在の選択肢 opt を取得
            // -----------------------------
            const char* opt = "";
            if (menu[idx].current_idx >= 0 && menu[idx].current_idx < menu[idx].opt_count) {
                if (menu[idx].options[menu[idx].current_idx] != NULL) {
                    opt = menu[idx].options[menu[idx].current_idx];
                }
            }

            // -----------------------------
            // ② Lift -（menu index 2）だけ mm を付ける
            // -----------------------------
            char opt_buf[20];
            if (idx == 2) {  
                snprintf(opt_buf, sizeof(opt_buf), "%s mm", opt);
                opt = opt_buf;
            }

            // -----------------------------
            // ③ カーソル表示
            // -----------------------------
            char mark = (mode == 2 && idx == cursor) ? '*' : ' ';
            char cur_mark = (idx == cursor) ? '>' : ' ';

            // -----------------------------
            // ④ レイアウト（20桁ぴったり）
            //
            // [1]cur_mark
            // [8]label（8文字固定）
            // [1]space
            // [1]colon ':'
            // [8]opt（最大8文字）
            // [1]space
            // [1]mark
            //
            // 合計：1 + 8 + 1 + 1 + 8 + 1 + 1 = 21 （表示は20）
            // -----------------------------
            snprintf(buf, sizeof(buf),
                     "%c%-8.8s:%-8.8s %c",  // ADD 最後のスペース1個追加で、ごみ表示　m は消えるが、設定画面選択の * マークは19文字目になる
                     cur_mark,
                     menu[idx].label,
                     opt,
                     mark);

            lcd.print(buf);

        } else {
            lcd.print("                    "); 
        }
    }
}

// ---------------------------------------------------------
// 設定画面へ戻す（CamAnalyzer終了後に呼ばれる）
// ---------------------------------------------------------
void lcd_return_to_setting_screen() {
    // UI 状態を MENU_SEL (=1) に戻す
    extern int current_mode;
    extern int menu_cursor;
    extern MenuEntry menu_data[];

    current_mode = 1;  // MENU_SEL

    // 設定画面を描画
    display_setting_screen(menu_cursor, 1, menu_data);
}

