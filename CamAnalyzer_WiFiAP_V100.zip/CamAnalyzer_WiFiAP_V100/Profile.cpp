/*
 * @file    Profile.cpp
 * @brief   設定(角度計算、RPM計算、リニアゲージ変換)
 * @author  yoshio ide
 * @date    2026-05-01
 *
 * [作成履歴 / Update History]
 * 2026/04/19 - 新規作成 (v1.0.0)
 *
 *
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#include "Profile.h"
#include <Arduino.h>

/*********************************************
 * 今後はこの数字1箇所を変更するだけでOKです ★
 ********************************************/
// 4逓倍後の1回転あたりの総カウント数を指定します。
// 例：4逓倍前が2000カウントなら 2000 * 4 = 8000 を入力
// 例：4逓倍前が1000カウントなら 1000 * 4 = 4000 を入力
float current_pulses_per_rev = 4000.0f; 


// 角度の計算(パルス → 角度変換)
void calculate_profile(int raw_count, char* angle_buf, int range_type, int rotation_dir) {
    // 1. 回転方向の反転処理
    if (rotation_dir == 1) {
        raw_count = -raw_count;
    }

    // ★修正：current_pulses_per_rev を使用して自動算出
    float degrees_per_pulse = 360.0f / current_pulses_per_rev;

    if (range_type == 2) {
        // 【1080度モード：繰り返さない】
        float angle = (float)raw_count * degrees_per_pulse;
        
        // 符号を考慮して表示（小数点以下2桁）
        if (angle < 0.0f) {
            snprintf(angle_buf, 13, "-%.2f", fabs(angle));
        } else {
            snprintf(angle_buf, 13, "%.2f", angle);
        }
    } else {
        // 【通常モード：360度または720度で繰り返す】
        // 選択されたRange（360度または720度）に必要なパルス数を自動計算
        // ★修正：current_pulses_per_rev を使用して自動算出
        int max_pulses = (range_type == 1) ? (int)(current_pulses_per_rev * 2.0f) : (int)current_pulses_per_rev;

        int wrapped_count = raw_count % max_pulses;
        if (wrapped_count < 0) wrapped_count += max_pulses;

        float angle = (float)wrapped_count * degrees_per_pulse;
        snprintf(angle_buf, 13, "%.2f", angle);
    }
}

// 角度用パルスの変化量からRPMを計算
void calculate_rpm_from_pulses(int current_raw, int last_raw, uint32_t duration_ms, char* rpm_buf) {
    // 0除算によるフリーズ防止
    if (duration_ms == 0) {
        snprintf(rpm_buf, 13, "0");
        return;
    }

    // 期間内のパルス変化量を計算
    int diff = abs(current_raw - last_raw);
    
    // 設定された PULSES_PER_REV を使って自動計算
    // ★修正：current_pulses_per_rev を使用して自動算出
    float rpm = ((float)diff / current_pulses_per_rev) * (60000.0f / (float)duration_ms);


    if (rpm > 15000) rpm = 0; // 異常値ガード
    snprintf(rpm_buf, 13, "%.0f", rpm);
}

// リニアゲージパルスの変化量からmmを計算
void calculate_Linear_Gage(int current_raw, char* Linear_buf) {

    // カウント値を mm に変換 (1カウント = 10 um = 0.01 mm)
    double distance_mm = current_raw * 0.01;
    //snprintf(Linear_buf, 13, "%-5.2f mm", distance_mm);
    snprintf(Linear_buf, 13, "%.2f", distance_mm);   // ← mm を付けない

}

// raw → mm 変換（GS-1730A：1カウント = 0.01mm）
float convert_linear_raw_to_mm(int16_t raw) {
    return raw * 0.01f;
}




