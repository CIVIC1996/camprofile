/* 
 * @file    CamAnalyzer.cpp
 * @brief   アナライザー(波形解析、データ記録、CSVダンプ（デバッグ用）、フィルタ処理)
 * @author  yoshio ide
 * @date    2026-07-01
 * 
 * [作成履歴 / Update History]
 * 2026/07/01 - 新規作成 (v1.0.0)
 * 2026/07/01 - 開始表示追加
 * 2026/07/04 - フィルタ追加　5点移動平均 Savitzky–Golay
 * 2026/07/10 - rel 修正①：angle_raw_buf に「rel 値」を記録する
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#include "CamAnalyzer.h"
#include "Encoder_PCNT.h"
#include "setting.h"
#include "Lcd_driver.h"
#include "Buzzer_Pi.h"
#include "WiFi_AP.h"

// 最大 8000P/R × 3回転 = 24000サンプルまで対応
int16_t angle_raw_buf[CAM_MAX_SAMPLES];
int16_t linear_raw_buf[CAM_MAX_SAMPLES];

// 状態
static CamPhase cam_phase = CAM_PHASE_NONE;
int pulses_per_rev = 4000;
int total_pulses_to_record = 0;

// 累積パルス用
static int cumulative_angle_raw = 0;
static int prev_angle_raw       = 0;

// 角度基準（rel = cumulative_angle_raw - phase_start_angle_raw）
static int phase_start_angle_raw = 0;

// この測定で使うバッファ範囲
int buf_start = 0;
int buf_end   = 0;

// 解析結果
float BTDC_IO = 0;
float ABDC_IC = 0;
float Duration_IN = 0;
float MaxLift_IN = 0;
float MaxLiftAngle_IN = 0;
float LobeCenter_IN = 0;

float BBDC_EO = 0;
float ATDC_EC = 0;
float Duration_EX = 0;
float MaxLift_EX = 0;
float MaxLiftAngle_EX = 0;
float LobeCenter_EX = 0;

float Overlap = 0;

// main_values は main.ino 側で定義
extern const char* main_labels[17];
extern char main_values[17][16];

// ---------------------------------------------------------
// LCD 表示用 main_values[] に書き込む
// ---------------------------------------------------------
void cam_write_results_to_main_values()
{
    // 吸気側
    snprintf(main_values[4],  16, "%.2f", BTDC_IO);
    snprintf(main_values[5],  16, "%.2f", ABDC_IC);
    snprintf(main_values[8],  16, "%.2f", Duration_IN);

    snprintf(main_values[11], 16, "%.2f", LobeCenter_IN);
    snprintf(main_values[12], 16, "%.2f", MaxLiftAngle_IN);
    snprintf(main_values[13], 16, "%.2f", MaxLift_IN);

    // 排気側
    snprintf(main_values[6],  16, "%.2f", BBDC_EO);
    snprintf(main_values[7],  16, "%.2f", ATDC_EC);
    snprintf(main_values[9],  16, "%.2f", Duration_EX);

    snprintf(main_values[14], 16, "%.2f", LobeCenter_EX);
    snprintf(main_values[15], 16, "%.2f", MaxLiftAngle_EX);
    snprintf(main_values[16], 16, "%.2f", MaxLift_EX);

    // Overlap
    if (BTDC_IO > 0.0f && ATDC_EC > 0.0f) {
        snprintf(main_values[10], 16, "%.2f", Overlap);
    }
}

// ---------------------------------------------------------
// 波形解析（IN/EX 共通）
// buf_start から total_pulses_to_record 分を解析
// ---------------------------------------------------------
void analyze_cam_profile(bool is_intake, int filter_mode)
{
    int ppr   = pulses_per_rev;
    int total = total_pulses_to_record;

    float deg_per_pulse = 360.0f / (float)ppr;

    float lift_threshold = atof(menu_data[2].options[menu_data[2].current_idx]);

    // ---------------------------------------------------------------------
    // フィルタ処理（linear_raw_buf[buf_start + i] に対して）
    // フィルタを適用した場合は、元データは失われるので、必要な場合は、Filter=None
    // ---------------------------------------------------------------------
    if (filter_mode == 1) {
        // 5点移動平均
        for (int i = 2; i < total - 2; i++) {
            int idx = buf_start + i;
            linear_raw_buf[idx] = (
                linear_raw_buf[idx-2] +
                linear_raw_buf[idx-1] +
                linear_raw_buf[idx]   +
                linear_raw_buf[idx+1] +
                linear_raw_buf[idx+2]
            ) / 5;
        }
    }
    else if (filter_mode == 2) {
        // Savitzky–Golay 5点
        for (int i = 2; i < total - 2; i++) {
            int idx = buf_start + i;
            linear_raw_buf[idx] =
                (-3 * linear_raw_buf[idx-2] +
                 12 * linear_raw_buf[idx-1] +
                 17 * linear_raw_buf[idx]   +
                 12 * linear_raw_buf[idx+1] +
                 -3 * linear_raw_buf[idx+2]) / 35;
        }
    }

    // ---------------------------------------------------------
    // 開閉角と最大リフト検出
    // ---------------------------------------------------------
    int   open_idx      = -1;   // buf_start からの相対 index
    int   close_idx     = -1;
    float max_lift      = -1e9f;
    int   max_lift_idx  = 0;

    for (int i = 0; i < total; i++) {

        int idx = buf_start + i;
        float lift_mm = (float)linear_raw_buf[idx] * 0.01f;

        if (open_idx < 0 && lift_mm >= lift_threshold) {
            open_idx = i;
        }

        if (lift_mm > max_lift) {
            max_lift     = lift_mm;
            max_lift_idx = i;
        }

        if (open_idx >= 0 && lift_mm < lift_threshold) {
            close_idx = i;
            break;
        }
    }

    if (open_idx < 0 || close_idx < 0) {
        Serial.println("解析失敗：開閉角が検出できません");

        // ★ main_values をクリアして残留表示を防ぐ
        snprintf(main_values[4],  16, "--");
        snprintf(main_values[5],  16, "--");
        snprintf(main_values[6],  16, "--");
        snprintf(main_values[7],  16, "--");
        snprintf(main_values[8],  16, "--");
        snprintf(main_values[9],  16, "--");
        snprintf(main_values[10], 16, "--");
        snprintf(main_values[11], 16, "--");
        snprintf(main_values[12], 16, "--");
        snprintf(main_values[13], 16, "--");
        snprintf(main_values[14], 16, "--");
        snprintf(main_values[15], 16, "--");
        snprintf(main_values[16], 16, "--");

        // display_main_screen(0, main_labels, main_values);

        return;
    }

    // ---------------------------------------------------------
    // 最大リフト角の補間（buf_start + max_lift_idx 周辺）
    // ---------------------------------------------------------
    float max_deg;

    if (max_lift_idx > 0 && max_lift_idx < total - 1) {

        int idx_m1 = buf_start + max_lift_idx - 1;
        int idx    = buf_start + max_lift_idx;
        int idx_p1 = buf_start + max_lift_idx + 1;

        float y1 = linear_raw_buf[idx_m1];
        float y2 = linear_raw_buf[idx];
        float y3 = linear_raw_buf[idx_p1];

        float denom = (y1 - 2*y2 + y3);

        if (denom != 0.0f) {
            float delta = 0.5f * (y1 - y3) / denom;
            float max_index_subpulse = (float)max_lift_idx + delta;

            max_deg = max_index_subpulse * deg_per_pulse;
        } else {
            max_deg = (float)max_lift_idx * deg_per_pulse;
        }
    }
    else {
        max_deg = (float)max_lift_idx * deg_per_pulse;
    }

    // ---------------------------------------------------------
    // 角度計算（open_idx/close_idx は 0〜total-1）
    // ---------------------------------------------------------
    float open_deg  = (float)open_idx  * deg_per_pulse;
    float close_deg = (float)close_idx * deg_per_pulse;

    float duration    = close_deg - open_deg;
    float lobe_center = open_deg + duration * 0.5f;

    if (is_intake) {
        BTDC_IO         = open_deg;
        ABDC_IC         = close_deg;
        Duration_IN     = duration;
        MaxLift_IN      = max_lift;
        MaxLiftAngle_IN = max_deg;
        LobeCenter_IN   = lobe_center;

        Serial.println("=== Intake解析完了 ===");

    } else {
        BBDC_EO         = open_deg;
        ATDC_EC         = close_deg;
        Duration_EX     = duration;
        MaxLift_EX      = max_lift;
        MaxLiftAngle_EX = max_deg;
        LobeCenter_EX   = lobe_center;

        Serial.println("=== Exhaust解析完了 ===");
    }

    if (BTDC_IO > 0.0f && ATDC_EC > 0.0f) {
        Overlap = ATDC_EC - BTDC_IO;
        Serial.print("Overlap: ");
        Serial.println(Overlap);
    }
}

// ---------------------------------------------------------
// データダンプ（buf_start〜buf_start+total_pulses_to_record-1）
// ---------------------------------------------------------
void cam_analyzer_dump_serial(int start_idx, bool start_zero, int range_pulses)
{
    Serial.println("=== CamAnalyzer DATA DUMP ===");

    float deg_per_pulse = 360.0f / (float)pulses_per_rev;

    Serial.print("total_pulses_to_record : ");
    Serial.println(total_pulses_to_record);

    Serial.print("range_pulses : ");
    Serial.println(range_pulses);

    Serial.println(start_idx == 0 ? "[[[ Intake ]]]" : "[[[ Exhaust ]]]");

    Serial.print("deg_per_pulse : ");
    Serial.println(deg_per_pulse);

    Serial.print("buf_start : ");
    Serial.println(buf_start);

    Serial.println("raw_angle, angle_deg, raw_linear, linear_mm");

    int dump_start = buf_start;
    int dump_end   = buf_start + total_pulses_to_record;

    for (int i = dump_start; i < dump_end; i++) {

        float angle_deg = (float)angle_raw_buf[i] * deg_per_pulse;
        float linear_mm = (float)linear_raw_buf[i] * 0.01f;

        Serial.print(angle_raw_buf[i]);
        Serial.print(",");
        Serial.print(angle_deg, 2);
        Serial.print(",");
        Serial.print(linear_raw_buf[i]);
        Serial.print(",");
        Serial.println(linear_mm, 2);
    }

    Serial.println("=== CamAnalyzer END ===");
}


// ---------------------------------------------------------
// データダンプ CSV
// ---------------------------------------------------------
void cam_analyzer_dump_CSV(int start_idx, bool start_zero, int range_pulses)
{
    Serial.println("=== CamAnalyzer CSV Combined ===");

    float deg_per_pulse = 360.0f / (float)pulses_per_rev;

    Serial.println("index,rel_IN,angle_deg_IN,linear_raw_IN,linear_mm_IN,"
                   "rel_EX,angle_deg_EX,linear_raw_EX,linear_mm_EX");

    // ★ 書き込み側と完全一致させる物理配置
    int intake_start  = (start_idx == 0) ? 0 : range_pulses;
    int exhaust_start = (start_idx == 0) ? range_pulses : 0;

    Serial.print("start_zero : ");
    Serial.print(start_zero);
    Serial.print("  start_idx : ");
    Serial.print(start_idx);
    Serial.print("  intake_start : ");
    Serial.print(intake_start);
    Serial.print("  exhaust_start : ");
    Serial.println(exhaust_start);

    // Intake の長さは range_pulses（例：360°→4000）
    int intake_len  = range_pulses;
    Serial.print("intake_len : ");
    Serial.println(intake_len);

    // Exhaust の長さは total_pulses_to_record（例：0〜3999）
    int exhaust_len = total_pulses_to_record;
    Serial.print("exhaust_len : ");
    Serial.println(exhaust_len);

    int max_len = max(intake_len, exhaust_len);
    Serial.print("max_len : ");
    Serial.println(max_len);

    for (int i = 0; i < max_len; i++) {

        // Intake データ
        int rel_in = (i < intake_len) ? angle_raw_buf[intake_start + i] : 0;
        float deg_in = rel_in * deg_per_pulse;
        int raw_in = (i < intake_len) ? linear_raw_buf[intake_start + i] : 0;
        float mm_in = raw_in * 0.01f;

        // Exhaust データ
        int rel_ex = (i < exhaust_len) ? angle_raw_buf[exhaust_start + i] : 0;
        float deg_ex = rel_ex * deg_per_pulse;
        int raw_ex = (i < exhaust_len) ? linear_raw_buf[exhaust_start + i] : 0;
        float mm_ex = raw_ex * 0.01f;

        // ★ start_zero=0 のときだけ IN/EX を入れ替える（逆転補正）
        if (!start_zero) {
            int tmp_rel = rel_in;
            int tmp_raw = raw_in;
            float tmp_deg = deg_in;
            float tmp_mm  = mm_in;

            rel_in = rel_ex;
            raw_in = raw_ex;
            deg_in = deg_ex;
            mm_in  = mm_ex;

            rel_ex = tmp_rel;
            raw_ex = tmp_raw;
            deg_ex = tmp_deg;
            mm_ex  = tmp_mm;
        }

        Serial.print(i);
        Serial.print(",");

        Serial.print(rel_in);
        Serial.print(",");
        Serial.print(deg_in, 3);
        Serial.print(",");
        Serial.print(raw_in);
        Serial.print(",");
        Serial.print(mm_in, 3);
        Serial.print(",");

        Serial.print(rel_ex);
        Serial.print(",");
        Serial.print(deg_ex, 3);
        Serial.print(",");
        Serial.print(raw_ex);
        Serial.print(",");
        Serial.println(mm_ex, 3);
    }

    Serial.println("=== END CSV ===");
}



// ---------------------------------------------------------
// 測定開始
// start_idx : 0=Intake, 1=Exhaust
// range_type: 0=360, 1=720, 2=1080
// ppr_idx   : menu_data[4].current_idx (0:2000, 1:4000, 2:8000)
// start_zero: start_zero_requested
// ---------------------------------------------------------
static int last_intake_end_angle_raw = 0;

void cam_analyzer_start(int start_idx, int range_type, int ppr_idx, bool start_zero)
{
    // CSV Dounload用
    start_idx_global = start_idx;
    start_zero_global = start_zero;

    bool is_intake = (start_idx == 0);
    display_cam_start_screen(start_idx, range_type);

    pulses_per_rev = atoi(menu_data[4].options[ppr_idx]);
    if (pulses_per_rev <= 0) pulses_per_rev = 4000;

    int range_pulses = pulses_per_rev * (range_type + 1);

    cam_phase    = (start_idx == 0) ? CAM_PHASE_INTAKE : CAM_PHASE_EXHAUST;
    int filter_mode  = menu_data[7].current_idx;

    // この測定で使うバッファ範囲
    if (start_zero) {

        buf_start = 0;
        buf_end   = 0;
        total_pulses_to_record = 0;

        // ★ 全データ破棄
        for (int i = 0; i < CAM_MAX_SAMPLES; i++) {
            angle_raw_buf[i]  = 0;
            linear_raw_buf[i] = 0;
        }

        // ★ main_values を "--" にクリア
        for (int i = 4; i <= 16; i++) {
            snprintf(main_values[i], 16, "--");
        }

    } else {
        buf_start = range_pulses;   // 360→4000, 720→8000
    }
    buf_end = buf_start + range_pulses;

    // 角度カウンタは main.cpp の btnC で既に 0 にリセット済み
    int angle_raw0 = get_angle_raw_count();
    cumulative_angle_raw = angle_raw0;
    prev_angle_raw       = angle_raw0;

    // start_zero に応じて「基準角度」と「待機フラグ」を決める
    bool waiting_for_start = false;
    int  target_angle_raw  = 0;

    if (start_zero) {
        // 今の位置からすぐ測定開始
        phase_start_angle_raw = cumulative_angle_raw;
    } else {
        // 4000 or 8000 パルス位置まで待つ
        if (range_type == 0) {          // 360°
            target_angle_raw = pulses_per_rev;        // 4000
        } else if (range_type == 1) {   // 720°
            target_angle_raw = pulses_per_rev * 2;    // 8000
        } else {
            target_angle_raw = pulses_per_rev * 3;
        }

        waiting_for_start   = true;
        phase_start_angle_raw = target_angle_raw;
    }

    int last_rel = -1;
    int half_ppr = pulses_per_rev >> 1;

    while (true) {

        // 1. 角度取得
        int angle_raw  = get_angle_raw_count();
        int linear_raw = get_Linear_Gage_count();

        int diff = angle_raw - prev_angle_raw;

        // 2 .wrap 判定
        if (diff >  half_ppr) diff -= pulses_per_rev;
        if (diff < -half_ppr) diff += pulses_per_rev;

        cumulative_angle_raw += diff;
        prev_angle_raw = angle_raw;

        // ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
        // 3. 開始前の判定（ここでは rel を使ってはいけない）
        // ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
        if (waiting_for_start) {
            if (cumulative_angle_raw == target_angle_raw) {
                waiting_for_start = false;
                last_rel = -1;
            }
            continue;
        }

        // ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
        // 4. 開始後の処理（waiting_for_start=false のときだけ終了判定）
        // ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
        int rel = cumulative_angle_raw - phase_start_angle_raw;

        if (rel < 0) continue;

        // ★ 開始前は絶対に終了判定をしてはいけない
        if (!waiting_for_start) {

            // この測定で「何パルス分」記録するか
            int measure_pulses = range_pulses;

            // 360度・start_zero=false（2回目測定）のときは
            // Exhaust側は「1周分だけ」記録したいので pulses_per_rev にする
            if (!start_zero && range_type == 0) {
                measure_pulses = pulses_per_rev;
            }

            // 開始後だけ終了判定する
            if (rel >= measure_pulses) {

                total_pulses_to_record = measure_pulses;

                if (is_intake) {
                    last_intake_end_angle_raw = cumulative_angle_raw;
    // ★ ここにログを追加する
    // Serial.printf("INTAKE END cumulative_angle_raw = %d\n", cumulative_angle_raw);
    // Serial.printf("INTAKE END rel = %d\n", rel);

                } else {

        // ★ Exhaust 終了ログ（ここが正しい位置）
        // Serial.printf("EXHAUST END cumulative_angle_raw = %d\n", cumulative_angle_raw);
        // Serial.printf("EXHAUST END rel = %d\n", rel);

                }

                // 波形解析
                analyze_cam_profile(is_intake, filter_mode);

                // LCD 表示に書き込む
                cam_write_results_to_main_values();
                
                // Intake or Exhaust
                //cam_analyzer_dump_serial(start_idx, start_zero, measure_pulses);
                
                // Intake and Exhaust CSV
                //cam_analyzer_dump_CSV(start_idx, start_zero, measure_pulses);

                // 150ミリ秒間 確実に鳴らす
                play_tone_reliable(150);

                // WiFi_AP CSVダウウンロードデータ作成
                save_csv_to_spiffs();

                // 150ミリ秒間 ２回鳴らす（画面制御解放）
                play_tone_reliable(150);
                delay(300);
                play_tone_reliable(150);

                return;
            }
        }

        if (rel == last_rel) continue;
        last_rel = rel;

        int index = buf_start + rel;

        // ★ ここを rel 記録に変更（Intake/Exhaust 角度ズレ解消）
        angle_raw_buf[index] = (int16_t)rel;
        linear_raw_buf[index] = (int16_t)linear_raw;

    }
}

// ---------------------------------------------------------
// 測定開始画面
// ---------------------------------------------------------
void display_cam_start_screen(int start_mode, int range_type)
{
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Start CamAnalyzer");

    lcd.setCursor(0, 1);
    lcd.print("Mode : ");
    lcd.print(start_mode == 0 ? "Intake" : "Exhaust");

    lcd.setCursor(0, 2);
    lcd.print("Range: ");
    if (range_type == 0) lcd.print("360 deg");
    else if (range_type == 1) lcd.print("720 deg");
    else lcd.print("1080 deg");

    lcd.setCursor(0, 3);
    lcd.print("Measuring...");
}
