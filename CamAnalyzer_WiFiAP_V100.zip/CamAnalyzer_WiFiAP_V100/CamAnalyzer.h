/*
 * @file    CamAnalyzer.h
 * @author  yoshio ide
 * @brief   アナライザー
 * @date    2026-07-01
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */


#pragma once
#include <Arduino.h>

static const int CAM_MAX_PPR = 8000;
static const int CAM_MAX_REV = 2;
static const int CAM_MAX_SAMPLES = CAM_MAX_PPR * CAM_MAX_REV;

// CamPhase の定義
enum CamPhase {
    CAM_PHASE_NONE,
    CAM_PHASE_INTAKE,
    CAM_PHASE_EXHAUST
};

// 関数プロトタイプ
void cam_analyzer_start(int start_idx, int range_type, int ppr_idx, bool start_zero);

void cam_analyzer_dump_serial(int start_idx, bool start_zero, int range_pulses);

void cam_analyzer_dump_CSV(int start_idx, bool start_zero, int range_pulses);

void analyze_cam_profile(bool is_intake,int filter_mode);   // フィルタに変更

void cam_write_results_to_main_values();

void display_cam_start_screen(int start_mode, int range_type);



