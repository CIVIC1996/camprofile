/**
 * @file    WiFi_AP.h
 * @author  yoshio ide
 * @brief   ESP32 CamProfiler WiFi AP Mode (SPIFFS統合版)
 * @date    2026-07-23
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */
#pragma once

#include <WebServer.h>
#include <SPIFFS.h>

// CamAnalyzer の測定バッファ（型を完全一致させる）
extern int16_t angle_raw_buf[];
extern int16_t linear_raw_buf[];

extern int pulses_per_rev;
extern int buf_start;
extern int buf_end;
extern int total_pulses_to_record;

// WiFi AP グローバル
extern int start_idx_global;
extern bool start_zero_global;

// WiFi AP 制御関数
void wifi_start_ap();
void wifi_stop();
void wifi_loop();
bool wifi_is_active();

// CSV 保存（SPIFFS）
void save_csv_to_spiffs();


