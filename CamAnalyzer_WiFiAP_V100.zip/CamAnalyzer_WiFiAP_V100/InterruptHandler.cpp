/**
 * @file    InterruptHandler.cpp
 * @brief   割込み(ボタン割り込み（デバウンス付き）)
 * @author  yoshio ide
 * @date    2026-05-01
 * 
 * [作成履歴 / Update History]
 * 2026/04/19 - 新規作成 (v1.0.0)
 * 2026/05/03 - 割込み処理
 * 
 * 
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#include "InterruptHandler.h"

volatile bool btnA_pressed = false; 
volatile bool btnB_pressed = false; 
volatile bool btnC_pressed = false;
volatile bool btnD_pressed = false;
volatile bool btnE_pressed = false;
volatile bool btnF_pressed = false;

// esp_timer_get_time() は 64bitのマイクロ秒を返すため型を変更
uint64_t last_us_a = 0, last_us_b = 0, last_us_c = 0, last_us_d = 0, last_us_e = 0, last_us_f = 0;
// デバウンス時間をマイクロ秒に変換 (200ms = 200,000us)
const uint32_t DEBOUNCE_US = 200 * 1000;

void IRAM_ATTR isr_buttonA() {
    uint64_t now = esp_timer_get_time();
    if (now - last_us_a > DEBOUNCE_US) { btnA_pressed = true; last_us_a = now; }
}
void IRAM_ATTR isr_buttonB() {
    uint64_t now = esp_timer_get_time();
    if (now - last_us_b > DEBOUNCE_US) { btnB_pressed = true; last_us_b = now; }
}
void IRAM_ATTR isr_buttonC() {
    uint64_t now = esp_timer_get_time();
    if (now - last_us_c > DEBOUNCE_US) { btnC_pressed = true; last_us_c = now; }
}
void IRAM_ATTR isr_buttonD() {
    uint64_t now = esp_timer_get_time();
    if (now - last_us_d > DEBOUNCE_US) { btnD_pressed = true; last_us_d = now; }
}
void IRAM_ATTR isr_buttonE() {
    uint64_t now = esp_timer_get_time();
    if (now - last_us_e > DEBOUNCE_US) { btnE_pressed = true; last_us_e = now; }
}
void IRAM_ATTR isr_buttonF() {
    uint64_t now = esp_timer_get_time();
    if (now - last_us_f > DEBOUNCE_US) { btnF_pressed = true; last_us_f = now; } 
}

void init_interrupts() {
    pinMode(PIN_BUTTON_A, INPUT_PULLUP);
    pinMode(PIN_BUTTON_B, INPUT_PULLUP);
    pinMode(PIN_BUTTON_C, INPUT_PULLUP);
    pinMode(PIN_BUTTON_D, INPUT_PULLUP);
    pinMode(PIN_BUTTON_E, INPUT_PULLUP);
    pinMode(PIN_BUTTON_F, INPUT_PULLUP);

    attachInterrupt(PIN_BUTTON_A, isr_buttonA, FALLING);
    attachInterrupt(PIN_BUTTON_B, isr_buttonB, FALLING);
    attachInterrupt(PIN_BUTTON_C, isr_buttonC, FALLING);
    attachInterrupt(PIN_BUTTON_D, isr_buttonD, FALLING);
    attachInterrupt(PIN_BUTTON_E, isr_buttonE, FALLING);
    attachInterrupt(PIN_BUTTON_F, isr_buttonF, FALLING);    
}