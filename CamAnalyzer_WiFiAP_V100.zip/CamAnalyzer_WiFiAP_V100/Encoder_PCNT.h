/*
 * @file    Encoder_PCNT.h
 * @author  yoshio ide
 * @brief   ロータリーエンコーダー関数
 * @date    2026-05-01
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#pragma once

#include <Arduino.h>
#include "driver/pulse_cnt.h"

void init_encoder(int pin_a, int pin_b);        // メニュー用
void init_angle_encoder(int pin_a, int pin_b);  // 角度用
void init_Linear_Gage(int pin_a, int pin_b);    // Linear Gage 小野測器

int get_encoder_count();
int get_angle_raw_count();
int get_Linear_Gage_count();
void reset_encoder_count();

void reset_angle_encoder_count();
void reset_Linear_Gage_count();