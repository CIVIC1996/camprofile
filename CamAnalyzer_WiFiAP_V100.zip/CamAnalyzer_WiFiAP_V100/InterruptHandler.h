/*
 * @file    InterruptHandler.h
 * @author  yoshio ide
 * @brief   割込み
 * @date    2026-05-01
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
  */

#pragma once

#include <Arduino.h>

#define PIN_BUTTON_A 5  // メニュー設定用
#define PIN_BUTTON_B 4  // 詳細設定用

#define PIN_BUTTON_C 33 // 33
#define PIN_BUTTON_D 32 // 32
#define PIN_BUTTON_E 18 // // 25 → 18 に変更
#define PIN_BUTTON_F 23 // 23


extern volatile bool btnA_pressed;
extern volatile bool btnB_pressed;
extern volatile bool btnC_pressed;  // 角度リセット
extern volatile bool btnD_pressed;  // ダイヤルゲージリセット
extern volatile bool btnE_pressed;  // 
extern volatile bool btnF_pressed;  //

void init_interrupts();
void IRAM_ATTR isr_buttonA();
void IRAM_ATTR isr_buttonB();
void IRAM_ATTR isr_buttonC();
void IRAM_ATTR isr_buttonD();
void IRAM_ATTR isr_buttonE();
void IRAM_ATTR isr_buttonF();

