/*
 * @file    Buzzer.cpp
 * @brief   ブザー制御
 * @author  yoshio ide
 * @date    2026-07-01
 * 
 * [作成履歴 / Update History]
 * 2026/05-01 - 新規作成 (v1.0.0)
 * 
 * 
 * 
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#include <Arduino.h>
#include "Buzzer_Pi.h"

#define BUZZER_PIN 19   // ★あなたの環境で最も安全なピン

void init_simple_buzzer() {
    pinMode(BUZZER_PIN, OUTPUT);
    digitalWrite(BUZZER_PIN, LOW);   // 初期は無音
}

void play_tone_reliable(uint32_t duration_ms) {
    // freq_hz は無視（アクティブブザーは周波数不要）
    digitalWrite(BUZZER_PIN, HIGH);  // 鳴らす
    delay(duration_ms);
    digitalWrite(BUZZER_PIN, LOW);   // 止める
}
