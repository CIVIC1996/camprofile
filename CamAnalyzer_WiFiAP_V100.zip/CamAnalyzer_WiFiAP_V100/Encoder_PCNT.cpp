/*
 * @file    Encoder_PCNT.cpp
 * @brief   ロータリーエンコーダー制御(角度・リニアゲージ・メニュー用エンコーダの PCNT 制御)
 * @author  yoshio ide
 * @date    2026-05-01
 * 
 * [作成履歴 / Update History]
 * 2026/04/19 - 新規作成 (v1.0.0)
 * 2026/04/19 - 等倍制度と2倍精度。
 * 2026/04/25 - 4倍を追加。
 * 
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#include "Encoder_PCNT.h"

// 2つのユニットハンドルを定義
pcnt_unit_handle_t pcnt_unit_menu = NULL;   // メニュー・スクロール用
pcnt_unit_handle_t pcnt_unit_angle = NULL;  // 角度計測用
pcnt_unit_handle_t pcnt_unit_Linear = NULL; // Linear Gage用


// --- メニュー用エンコーダーの初期化 ---
void init_encoder(int pin_a, int pin_b) {
    pcnt_unit_config_t unit_config = {};
    unit_config.high_limit = 1000;
    unit_config.low_limit = -1000;
    pcnt_new_unit(&unit_config, &pcnt_unit_menu); // pcnt_unit_menu を使用

    pcnt_glitch_filter_config_t filter_config = { .max_glitch_ns = 1000 };
    pcnt_unit_set_glitch_filter(pcnt_unit_menu, &filter_config);

    pcnt_chan_config_t chan_a = { .edge_gpio_num = pin_a, .level_gpio_num = pin_b };
    pcnt_chan_config_t chan_b = { .edge_gpio_num = pin_b, .level_gpio_num = pin_a };
    pcnt_channel_handle_t h_a, h_b;
    pcnt_new_channel(pcnt_unit_menu, &chan_a, &h_a);
    pcnt_new_channel(pcnt_unit_menu, &chan_b, &h_b);


    // 修正：両エッジでカウントさせ、1クリックでカウントが4増えるようにする
    pcnt_channel_set_edge_action(h_a, PCNT_CHANNEL_EDGE_ACTION_INCREASE, PCNT_CHANNEL_EDGE_ACTION_DECREASE);
    pcnt_channel_set_level_action(h_a, PCNT_CHANNEL_LEVEL_ACTION_KEEP, PCNT_CHANNEL_LEVEL_ACTION_INVERSE);
    pcnt_channel_set_edge_action(h_b, PCNT_CHANNEL_EDGE_ACTION_INCREASE, PCNT_CHANNEL_EDGE_ACTION_DECREASE);
    pcnt_channel_set_level_action(h_b, PCNT_CHANNEL_LEVEL_ACTION_INVERSE, PCNT_CHANNEL_LEVEL_ACTION_KEEP);

    pcnt_unit_enable(pcnt_unit_menu);
    pcnt_unit_clear_count(pcnt_unit_menu);
    pcnt_unit_start(pcnt_unit_menu);
}

// --- 角度計測用エンコーダーの初期化 (4逓倍) ---
void init_angle_encoder(int pin_a, int pin_b) {
    pcnt_unit_config_t unit_config = {};
    unit_config.high_limit = 32000;
    unit_config.low_limit = -32000;
    pcnt_new_unit(&unit_config, &pcnt_unit_angle); // pcnt_unit_angle を使用

    pcnt_glitch_filter_config_t filter_config = { .max_glitch_ns = 1000 };
    pcnt_unit_set_glitch_filter(pcnt_unit_angle, &filter_config);

    pcnt_chan_config_t chan_a = { .edge_gpio_num = pin_a, .level_gpio_num = pin_b };
    pcnt_chan_config_t chan_b = { .edge_gpio_num = pin_b, .level_gpio_num = pin_a };
    pcnt_channel_handle_t h_a, h_b;
    pcnt_new_channel(pcnt_unit_angle, &chan_a, &h_a);
    pcnt_new_channel(pcnt_unit_angle, &chan_b, &h_b);

    // 4逓倍にするための設定 (両相・両エッジで Increase/Decrease)
    pcnt_channel_set_edge_action(h_a, PCNT_CHANNEL_EDGE_ACTION_INCREASE, PCNT_CHANNEL_EDGE_ACTION_DECREASE);
    pcnt_channel_set_level_action(h_a, PCNT_CHANNEL_LEVEL_ACTION_KEEP, PCNT_CHANNEL_LEVEL_ACTION_INVERSE);
    pcnt_channel_set_edge_action(h_b, PCNT_CHANNEL_EDGE_ACTION_INCREASE, PCNT_CHANNEL_EDGE_ACTION_DECREASE);
    pcnt_channel_set_level_action(h_b, PCNT_CHANNEL_LEVEL_ACTION_INVERSE, PCNT_CHANNEL_LEVEL_ACTION_KEEP);

    pcnt_unit_enable(pcnt_unit_angle);
    pcnt_unit_clear_count(pcnt_unit_angle);
    pcnt_unit_start(pcnt_unit_angle);
}

// Linear Gage 小野測器 GS-1730A の初期化 (4逓倍) ---
void init_Linear_Gage(int pin_a, int pin_b) {
    pcnt_unit_config_t unit_config = {};
    unit_config.high_limit = 32000;
    unit_config.low_limit = -32000;
    pcnt_new_unit(&unit_config, &pcnt_unit_Linear); // pcnt_unit_Linear を使用

    pcnt_glitch_filter_config_t filter_config = { .max_glitch_ns = 1000 };
    pcnt_unit_set_glitch_filter(pcnt_unit_Linear, &filter_config);

    pcnt_chan_config_t chan_a = { .edge_gpio_num = pin_a, .level_gpio_num = pin_b };
    pcnt_chan_config_t chan_b = { .edge_gpio_num = pin_b, .level_gpio_num = pin_a };
    pcnt_channel_handle_t h_a, h_b;
    pcnt_new_channel(pcnt_unit_Linear, &chan_a, &h_a);
    pcnt_new_channel(pcnt_unit_Linear, &chan_b, &h_b);

    // 4逓倍にするための設定 (両相・両エッジで Increase/Decrease)
    pcnt_channel_set_edge_action(h_a, PCNT_CHANNEL_EDGE_ACTION_INCREASE, PCNT_CHANNEL_EDGE_ACTION_DECREASE);
    pcnt_channel_set_level_action(h_a, PCNT_CHANNEL_LEVEL_ACTION_KEEP, PCNT_CHANNEL_LEVEL_ACTION_INVERSE);
    pcnt_channel_set_edge_action(h_b, PCNT_CHANNEL_EDGE_ACTION_INCREASE, PCNT_CHANNEL_EDGE_ACTION_DECREASE);
    pcnt_channel_set_level_action(h_b, PCNT_CHANNEL_LEVEL_ACTION_INVERSE, PCNT_CHANNEL_LEVEL_ACTION_KEEP);

    pcnt_unit_enable(pcnt_unit_Linear);
    pcnt_unit_clear_count(pcnt_unit_Linear);
    pcnt_unit_start(pcnt_unit_Linear);
}

int get_encoder_count() {
    int count = 0;
    if (pcnt_unit_menu) pcnt_unit_get_count(pcnt_unit_menu, &count);
    return count;
}

int get_angle_raw_count() {
    int count = 0;
    if (pcnt_unit_angle) pcnt_unit_get_count(pcnt_unit_angle, &count);
    return count;
}

int get_Linear_Gage_count() {
    int count = 0;
    if (pcnt_unit_Linear) pcnt_unit_get_count(pcnt_unit_Linear, &count);
    return count;
}

void reset_encoder_count() { if (pcnt_unit_menu) pcnt_unit_clear_count(pcnt_unit_menu); }

void reset_angle_encoder_count() {
    if (pcnt_unit_angle) {
        pcnt_unit_clear_count(pcnt_unit_angle);
    }
}

void reset_Linear_Gage_count() {
    if (pcnt_unit_Linear) {
        pcnt_unit_clear_count(pcnt_unit_Linear);
    }
}

