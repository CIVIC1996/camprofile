/*
 * @file    WiFi_AP.cpp
 * @brief   ESP32 CamProfiler WiFi AP Mode (SPIFFS統合版)
 * @author  yoshio ide
 * @date    2026-07-23
 * 
 * AP_SSID = "CamProfiler"  を探して接続　
 * AP_PASS = "12345678"
 * ipconfig 確認
 * http:/192.168.4.1 ESP32 CamProfiler AP Mode OK
 *
 * [作成履歴 / Update History]
 * 2026-07-23 - 新規作成 (v1.0.0)
 *
 * 
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */
#include <WiFi.h>      // ESP32 WiFi 機能
#include "WiFi_AP.h"
#include "Lcd_driver.h"
#include "InterruptHandler.h"
#include <SPIFFS.h>
#include <DNSServer.h>
#include <WebServer.h>


extern LiquidCrystal_I2C lcd;
extern void display_cam_start_screen(int start_mode, int range_type);

// ★ WiFi情報画面の extern が必要
extern void display_wifi_info_screen();

// CamAnalyzer から受け取るグローバル
int start_idx_global = 0;
bool start_zero_global = true;

// WebServer
WebServer server(80);
bool ap_active = false;

// DNSServer dnsServer;
DNSServer dnsServer;

// =========================
// CSV を SPIFFS に保存「高速版save_csv_to_spiffs()（f.printf 版）」
// =========================
void save_csv_to_spiffs() {

    File f = SPIFFS.open("/cam.csv", FILE_WRITE);
    if (!f) return;

    float deg_per_pulse = 360.0f / (float)pulses_per_rev;

    int range_pulses = buf_end - buf_start;

    int intake_start  = (start_idx_global == 0) ? 0 : range_pulses;
    int exhaust_start = (start_idx_global == 0) ? range_pulses : 0;

    int intake_len  = range_pulses;
    int exhaust_len = total_pulses_to_record;

    int max_len = max(intake_len, exhaust_len);

    // ★ 新しいヘッダ（5項目）
    f.println("index,rel_IN,angle_deg_IN,linear_mm_IN,linear_mm_EX");

    for (int i = 0; i < max_len; i++) {

        // ★ IN 側（角度は IN の rel_in から計算）
        int rel_in   = (i < intake_len) ? angle_raw_buf[intake_start + i] : 0;
        float deg_in = rel_in * deg_per_pulse;

        int raw_in   = (i < intake_len) ? linear_raw_buf[intake_start + i] : 0;
        float mm_in  = raw_in * 0.01f;

        // ★ EX 側（mm のみ）
        int raw_ex   = (i < exhaust_len) ? linear_raw_buf[exhaust_start + i] : 0;
        float mm_ex  = raw_ex * 0.01f;

        // ★ start_zero_global の入れ替えは mm のみでOK
        if (!start_zero_global) {
            float tmp_mm = mm_in;
            mm_in = mm_ex;
            mm_ex = tmp_mm;
        }

        // ★ 必要な項目だけ出力
        f.printf("%d,%d,%.3f,%.3f,%.3f\n",
                 i,
                 rel_in,
                 deg_in,
                 mm_in,
                 mm_ex);
    }

    f.close();
}


// 全項目版
// void save_csv_to_spiffs() {

//     File f = SPIFFS.open("/cam.csv", FILE_WRITE);
//     if (!f) return;

//     float deg_per_pulse = 360.0f / (float)pulses_per_rev;

//     int range_pulses = buf_end - buf_start;

//     int intake_start  = (start_idx_global == 0) ? 0 : range_pulses;
//     int exhaust_start = (start_idx_global == 0) ? range_pulses : 0;

//     int intake_len  = range_pulses;
//     int exhaust_len = total_pulses_to_record;

//     int max_len = max(intake_len, exhaust_len);

//     f.println("index,rel_IN,angle_deg_IN,linear_raw_IN,linear_mm_IN,"
//               "rel_EX,angle_deg_EX,linear_raw_EX,linear_mm_EX");

//     for (int i = 0; i < max_len; i++) {

//         int rel_in   = (i < intake_len) ? angle_raw_buf[intake_start + i] : 0;
//         float deg_in = rel_in * deg_per_pulse;
//         int raw_in   = (i < intake_len) ? linear_raw_buf[intake_start + i] : 0;
//         float mm_in  = raw_in * 0.01f;

//         int rel_ex   = (i < exhaust_len) ? angle_raw_buf[exhaust_start + i] : 0;
//         float deg_ex = rel_ex * deg_per_pulse;
//         int raw_ex   = (i < exhaust_len) ? linear_raw_buf[exhaust_start + i] : 0;
//         float mm_ex  = raw_ex * 0.01f;

//         if (!start_zero_global) {
//             int   tmp_rel = rel_in;
//             int   tmp_raw = raw_in;
//             float tmp_deg = deg_in;
//             float tmp_mm  = mm_in;

//             rel_in = rel_ex;
//             raw_in = raw_ex;
//             deg_in = deg_ex;
//             mm_in  = mm_ex;

//             rel_ex = tmp_rel;
//             raw_ex = tmp_raw;
//             deg_ex = tmp_deg;
//             mm_ex  = tmp_mm;
//         }

//         f.printf("%d,%d,%.3f,%d,%.3f,%d,%.3f,%d,%.3f\n",
//                  i,
//                  rel_in, deg_in, raw_in, mm_in,
//                  rel_ex, deg_ex, raw_ex, mm_ex);
//     }

//     f.close();
// }

// =========================
// WiFi AP 起動
// =========================
void wifi_start_ap() {

    WiFi.mode(WIFI_AP);
    WiFi.softAP("CamProfiler", "12345678");

    // ★ DNS（全ドメインを 192.168.4.1 に返す）
    dnsServer.start(53, "*", WiFi.softAPIP());

    // ★ Captive Portal 用の特別 URL（iPhone）
    server.on("/hotspot-detect.html", [](){
    server.sendHeader("Location", "/");
    server.send(302, "text/plain", "");
    });

    // ★ Captive Portal 用（Android）
    server.on("/generate_204", [](){
    server.sendHeader("Location", "/");
    server.send(302, "text/plain", "");
    });

    server.on("/connectivitycheck.gstatic.com/generate_204", [](){
    server.sendHeader("Location", "/");
    server.send(302, "text/plain", "");
    });

    // トップページ
    server.on("/", []() {
        String html = R"HTML(
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>CamProfiler WiFi</title>
<style>
body { font-family: Arial; background:#f0f0f0; padding:20px; }
.container { background:white; padding:20px; border-radius:10px; max-width:400px; margin:auto; }
button {
    width:100%; padding:15px; font-size:18px;
    background:#0078ff; color:white; border:none; border-radius:8px;
    margin-top:10px;
}
button:hover { background:#005fcc; }
</style>
</head>
<body>
<div class="container">
<h2>CamProfiler WiFi</h2>
<p>CSV データをダウンロード、またはスマホで閲覧できます。</p>

<a href="#" onclick="downloadCSV()"><button>CSV ダウンロード</button></a>
<a href="/viewcsv"><button>CSV 表示（スマホ用）</button></a>

</div>

<script>
function downloadCSV() {
    const now = new Date();
    const filename =
        "cam_" +
        now.getFullYear() + "-" +
        ("0"+(now.getMonth()+1)).slice(-2) + "-" +
        ("0"+now.getDate()).slice(-2) + "_" +
        ("0"+now.getHours()).slice(-2) + "-" +
        ("0"+now.getMinutes()).slice(-2) + "-" +
        ("0"+now.getSeconds()).slice(-2) +
        ".csv";

    window.location.href = "/csv?filename=" + filename;
}
</script>

</body>
</html>
)HTML";

        server.send(200, "text/html", html);
    });

    // CSV ダウンロード（SPIFFSから）
    server.on("/csv", []() {
        String filename = server.arg("filename");
        if (filename == "") filename = "cam_data.csv";

        File f = SPIFFS.open("/cam.csv", FILE_READ);
        if (!f) {
            server.send(404, "text/plain", "CSV not found");
            return;
        }

        server.sendHeader("Content-Type", "text/csv");
        server.sendHeader("Content-Disposition", "attachment; filename=" + filename);
        server.streamFile(f, "text/csv");
        f.close();
    });

    // CSV 表形式表示（SPIFFSのCSVを読む）
    server.on("/viewcsv", []() {

        server.sendHeader("Content-Type", "text/html; charset=UTF-8");
        server.sendHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        server.sendHeader("Pragma", "no-cache");
        server.sendHeader("Expires", "0");

        String html = R"HTML(
<!DOCTYPE html><html><head><meta charset='UTF-8'>
<title>CSV Viewer</title>
<style>
body{font-family:Arial;background:#f0f0f0;padding:10px;}
table{border-collapse:collapse;width:100%;}

/* ★ 固定ヘッダ（スクロールしてもヘッダが上に固定） */
#tbl th{
  position: sticky;
  top: 0;
  background: #ddd;   /* th の背景色を維持 */
  z-index: 10;
}

/* ★ 行の交互色（ストライプ） */
#tbl tr:nth-child(even){ background:#f9f9f9; }
#tbl tr:nth-child(odd){ background:#ffffff; }

th,td{border:1px solid #888;padding:6px;font-size:14px;}
th{background:#ddd;}
button{width:100%;padding:12px;font-size:16px;
background:#0078ff;color:white;border:none;border-radius:8px;margin-top:15px;}
</style>
</head><body>
<h2>CamProfiler CSV Viewer</h2>

<!-- 上ナビ -->
<div id='nav'></div>
<!-- 表 -->
<table id='tbl'>
  <thead></thead>
  <tbody></tbody>
</table>
<!-- 下ナビ（ここが重要） -->
<div id="nav2"></div>
<script>
let lines=[];
fetch('/csv_spiffs',{cache:'no-store'})
.then(r=>r.text())
.then(t=>{
  lines=t.trim().split('\n');
  showPage(0);
});
function showPage(p){
  const ROWS = 200;

  // ★ thead と tbody を取得
  const tblHead = document.querySelector('#tbl thead');
  const tblBody = document.querySelector('#tbl tbody');

  // ★ ヘッダ（thead に入れる）
  tblHead.innerHTML = `
    <tr>
      <th>index</th>
      <th>angle_deg_IN</th>
      <th>linear_mm_IN</th>
      <th>linear_mm_EX</th>
    </tr>
  `;

  // ★ データ行は tbody に入れる
  tblBody.innerHTML = '';

  let start = p * ROWS;
  let end = Math.min(start + ROWS, lines.length);

  for(let i = start; i < end; i++){
    let cols = lines[i].split(',');

    let row = '<tr>';
    row += `<td>${cols[0]}</td>`;
    row += `<td>${cols[2]}</td>`;
    row += `<td>${cols[3]}</td>`;
    row += `<td>${cols[4]}</td>`;
    row += '</tr>';

    tblBody.innerHTML += row;
  }

  // ★ 上ナビ
  let nav = document.getElementById('nav');
  nav.innerHTML = '';
  if(p > 0) nav.innerHTML += `<button onclick='showPage(${p-1})'>前へ</button>`;
  if(end < lines.length) nav.innerHTML += `<button onclick='showPage(${p+1})'>次へ</button>`;
  nav.innerHTML += `<button onclick="location.href='http://192.168.4.1/'">戻る</button>`;

  // ★ 下ナビ
  let nav2 = document.getElementById('nav2');
  nav2.innerHTML = '';
  if(p > 0) nav2.innerHTML += `<button onclick='showPage(${p-1})'>前へ</button>`;
  if(end < lines.length) nav2.innerHTML += `<button onclick='showPage(${p+1})'>次へ</button>`;
  nav2.innerHTML += `<button onclick="location.href='http://192.168.4.1/'">戻る</button>`;
}


</script>
</body></html>
)HTML";

        server.send(200, "text/html", html);
    });

    // viewer 用 生CSV（SPIFFSから）
    server.on("/csv_spiffs", []() {
        File f = SPIFFS.open("/cam.csv", FILE_READ);
        if (!f) {
            server.send(404, "text/plain", "CSV not found");
            return;
        }
        server.streamFile(f, "text/plain");
        f.close();
    });

    server.begin();
    ap_active = true;

    display_wifi_info_screen();

    while (ap_active) {
        server.handleClient();
        delay(10);

        if (btnE_pressed) {
            btnE_pressed = false;
            wifi_stop();
        }
    }
}

// =========================
// WiFi 情報画面
// =========================
void display_wifi_info_screen() {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("WiFi AP MODE");

    lcd.setCursor(0, 1);
    lcd.print("SSID: CamProfiler");

    lcd.setCursor(0, 2);
    lcd.print("PASS: 12345678");

    lcd.setCursor(0, 3);
    lcd.print("URL: 192.168.4.1");
}

// =========================
// WiFi AP 停止
// =========================
void wifi_stop() {
    if (!ap_active) return;

    server.stop();
    WiFi.softAPdisconnect(true);
    ap_active = false;
}

// =========================
// WiFi AP 稼働中か？
void wifi_loop() {
    if (ap_active) {
        server.handleClient();
    }
}

bool wifi_is_active() {
    return ap_active;
}
