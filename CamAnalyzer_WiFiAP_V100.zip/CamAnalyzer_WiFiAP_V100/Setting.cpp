/*
 * @file    Setting.cpp
 * @brief   設定(設定メニュー生成、Preferences保存・復帰)
 * @author  yoshio ide
 * @date    2026-05-01
 * 
 * [作成履歴 / Update History]
 * 2026/05-01 - 新規作成 (v1.0.0)
 * 2026/05/01 - 設定用ロータリエンコーダから各種初期設定を行う。(v1.1.0)
 * 2026/05/04 - ESP32の内蔵フラッシュメモリ（Preferencesライブラリ）を使用して、設定を保存・復帰させる機能を追加
 * 
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#include "setting.h"
#include <stdio.h>
#include <Preferences.h>
#include "Encoder_PCNT.h"

Preferences prefs;

// Lift用の文字列を保持するバッファ (151項目分、各5文字 "x.xx\0")
char dura_labels[151][5];

// 修正：Lift項目の初期化時に、151個の要素を持つポインタ配列であることを明示する、
// または、setting.h の MenuEntry.options が十分な大きさ（例: 151以上）の固定長配列である必要があります。
MenuEntry menu_data[] = {
    {"MODE", {"CAM", "CRANK", "Alternator"}, 3, 0, 0},
    // {"Range", {"0~360~0", "0~720~0", "0~1080~~"}, 3, 0, 0}, // 720　削除
    {"Range", {"0~360~0", "0~720~0"}, 2, 0, 0},
    {"Lift -", {NULL}, 151, 0, 0}, // 安全のためNULL初期化。サイズは構造体の定義（MAX_OPTIONS）に依存します。
    {"DIR", {"CW", "CCW"}, 2, 0, 0},
    {"P/R", {"2000", "4000", "8000"}, 3, 1, 1}, // デフォルト4000(index 1)
    {"Start", {"Intake", "Exhaust"}, 2, 0, 0},
    {"Reset", {"NO", "DATA CLR", "ALL CLR"}, 3, 0, 0}, // Reserve3 を「Reset」に変更しました
    // {"Calc", {"CAM", "CRANK"}, 2, 1, 1}   // 計算方法　MODE = CAM 選択時のみCRANKを選択できる MODE = CRANK 選択時はCRANKのみ
    {"Filter", {"None", "Smooth", "Prec."}, 3, 0, 0}   // None（フィルタなし）,Smooth (5pt Avg), Precision (SG Filter)
};


const int MENU_COUNT = sizeof(menu_data) / sizeof(MenuEntry);

// 起動時に0.00〜1.50の文字列を生成してセットする
void init_menu_options() {
    for (int i = 0; i <= 150; i++) {
        snprintf(dura_labels[i], 5, "%.2f", i * 0.01f);
        // 注意：setting.h内の MenuEntry 構造体で、options配列のサイズが
        // 151以上（例：const char* options[152]; などの固定長）になっていることを必ず確認してください。
        menu_data[2].options[i] = dura_labels[i]; 
    }
}

// デフォルト
void handle_default() {
    for (int i = 0; i < MENU_COUNT; i++) {
        menu_data[i].current_idx = menu_data[i].default_idx;
    }
}

// 設定をフラッシュメモリから読み込む
void load_settings() {
    prefs.begin("cam-gear", true); // 読み取り専用
    
    menu_data[0].current_idx = prefs.getInt("mode", 0);
    menu_data[1].current_idx = prefs.getInt("range", 0);
    menu_data[2].current_idx = prefs.getInt("lift", 0);
    menu_data[3].current_idx = prefs.getInt("dir", 0);
    menu_data[4].current_idx = prefs.getInt("puls", 1); // ★追加 1回転あたりカウント数   
    menu_data[7].current_idx = prefs.getInt("filter", 1); // ★追加 計算方法　基準  

    prefs.end();

    // 回転方向初期化
    int idir = menu_data[3].current_idx;;
    if (idir == 0) {
        // CW
        init_angle_encoder(13, 14);     // 角度計測用(13,14) ALT 2006/05/21 変更 12PINに接続すると、立ち上がらないため（競合?）

    } else {
        // CCW
        init_angle_encoder(14, 13);     // 角度計測用(13,14) ALT 2006/05/21 変更 12PINに接続すると、立ち上がらないため（競合?）

    }
    delay(200);

}

// 設定をフラッシュメモリに書き込む
void save_settings() {
    prefs.begin("cam-gear", false); // 書き込みモード
    
    prefs.putInt("mode", menu_data[0].current_idx);
    prefs.putInt("range", menu_data[1].current_idx);
    prefs.putInt("lift", menu_data[2].current_idx);
    prefs.putInt("dir", menu_data[3].current_idx);
    prefs.putInt("puls", menu_data[4].current_idx); // ★追加 1回転あたりカウント数  
    prefs.putInt("filter", menu_data[7].current_idx); // ★追加 計算方法　基準   

    prefs.end();
    Serial.println("Settings Saved!");
}