/*
 * @file    Profile.h
 * @author  yoshio ide
 * @brief   設定
 * @date    2026-05-01
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#pragma once

#include <Arduino.h>

// 外部の main.cpp から現在のパルス数を書き換えるための変数を宣言
extern float current_pulses_per_rev;

/**
 * @brief 角度の計算 (4000パルス/1回転)
 * @param raw_count 生のパルス数
 * @param angle_buf 書き込み先の文字列バッファ
 */
void calculate_profile(int raw_count, char* angle_buf, int range_type, int rotation_dir);

/**
 * @brief 角度用パルスの変化量からRPMを計算
 * @param current_raw 現在のパルス数
 * @param last_raw 前回の計算時のパルス数
 * @param duration_ms 経過時間
 * @param rpm_buf 書き込み先の文字列バッファ
 */
void calculate_rpm_from_pulses(int current_raw, int last_raw, uint32_t duration_ms, char* rpm_buf);

/**
 * @brief リニアゲージパルスの変化量からmmを計算
 * @param current_raw 生のパルス数
 * @param Linear_buf 書き込み先の文字列バッファ
 */
void calculate_Linear_Gage(int current_raw, char* Linear_buf);

float convert_linear_raw_to_mm(int16_t raw);





