/**
 * @file    Lcd_driver.h
 * @author  yoshio ide
 * @brief   i2c LCD関数
 * @date    2026-4-16
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#pragma once

#include <LiquidCrystal_I2C.h>
#include "setting.h"

extern LiquidCrystal_I2C lcd;
void init_lcd();

//void display_main_screen(int offset, const char* labels[], const char* values[]);
void display_main_screen(int offset,
                         const char* labels[],
                         char values[][16]);


void display_setting_screen(int cursor, int mode, MenuEntry* menu);

void lcd_return_to_setting_screen() ;
