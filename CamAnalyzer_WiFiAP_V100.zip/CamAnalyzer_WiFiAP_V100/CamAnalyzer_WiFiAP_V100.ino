/** main.cpp
 * @file    main
 * @brief   ESP32dによるカムプロフィール測定プログラム
 * @author  yoshio ide
 * @date    2026-05-01
 * @Board   ESP32_DEV_Module 
 * @ボードマネージャ = esp32 by Esprssif Systems (3.04)
 *                    Arduino ESP32 Boards by Arduino (2.0.18)
 * @version 1.0.0
 * 
 * [概要]
 * カムプロフィール測定を行う。
 * 表示はi2c LCD およびWifi接続による。
 * 
 * [ハードウェア構成]
 * - Board: ESP32-WROOM-32E (DevKit V1)
 * - rotary encoder:メニュー設定用 (A:27, B:26番ピン）
 * - rotary encoder: 多摩川精機(FA-CODER 48-1000P6-L6-5V TS 5207 N577 SER.NoB17524) （A:13, B:14番ピン）
 * - dial gauge: 小野測器 GS-1730A （A:35, B:36番ピン）→（A:34, B:35番ピン）
 * - i2c LCD 5V 4行 × 20文字 （21,22 番ピン）
 *
 *
 * 1.main.ino               : UI状態遷移（UI状態管理、リアルタイム表示、設定操作、測定開始トリガー)
 *                              MAIN    : 測定データのリアルタイム表示モード。
 *                              MENU_SEL: 設定項目の選択モード。
 *                              OPT_SEL : 設定値の変更モード。
 * 2.CamAnalyzer.cpp        : 波形解析、データ記録、CSVダンプ、フィルタ処理
 * 3.Encoder_PCNT.cpp       : 角度・リニアゲージ・メニュー用エンコーダの PCNT 制御
 * 4.InterruptHandler.cpp   : ボタン割り込み（デバウンス付き）ボタンA/Bのチャタリング防止割り込み処理。
 * 5.Lcd_driver.cpp         : LCD描画（メイン画面・設定画面）スクロール表示、等号整列、動的ラベル描画。
 * 6.Profile.cpp            : 角度計算、RPM計算、リニアゲージ変換。
 * 7.setting.cpp            : 設定メニュー生成(0.01mm単位（151項目）の動的メニュー生成)、Preferences保存・復帰、初期化機能。
 * 8. Buzzer_Pi.cpp         : ブザー制御
 *
 * [作成履歴 / Update History]
 * 2026/07/01 - 新規作成 (v1.0.0)
 * 2026/07/02 - Calc計算方法追加 CAM CRANK ESP32CH340C_NEW_15_BTDC
 * 2026/07/03 - 720度 削除
 * 2026/07/04 - Calc計算方法削除 CAM CRANK  ESP32CH340C_NEW_16
 * 2026/07/05 - データダンプ（デバッグ用）修正ESP32CH340C_NEW_17_OK
 * 2026/07/05 - Intake / Exhaus測定順改善（どちらからでも測定可能とした）
 * 2026/07/21 - Wifi機能追加
 * 2026/08/01 - version 1.0.0
 *
 *
 *
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#include <Arduino.h>
#include "Profile.h"
#include "Encoder_PCNT.h"
#include "InterruptHandler.h"
#include "Lcd_driver.h"
#include "setting.h"
#include "Buzzer_Pi.h"
#include "CamAnalyzer.h"
#include "WiFi_AP.h"
#include <SPIFFS.h> 

// 状態管理の定義
enum ScreenMode {
    MAIN,       // リアルタイム測定表示
    MENU_SEL,   // 設定項目の選択
    OPT_SEL     // 設定値の変更
};

ScreenMode current_mode = MAIN;
int menu_cursor = 0;        // 現在選択されているメニューのインデックス
int main_scroll_offset = 0; // メイン画面のスクロール位置（0～4）

// RPM計算用の変数
uint32_t last_rpm_time = 0;
int last_angle_raw = 0;

// LCD書き込み用バッファ
char angle_str[20];
char rpm_str[20];
char linear_str[20];

// メイン画面の項目定義
const char* main_labels[] = {
    "RPM",
    "Angle",
    "Linear",
    "Lift -",
    // "BTDC (IO)",
    // "ABDC (IC)",
    // "BBDC (EO)",
    // "ATDC (EC)",
    "IO",
    "IC",
    "EO",
    "EC",
    "Dura.IN",
    "Dura.EX",
    "Overlap",
    "LobCen (IN)",     // Lobe Center Angle IN
    "MaxLift(IN)",     // Max Lift Angle    IN
    "LiftMax(IN)",     // 最大リフト量 mm   IN
    "LobCen (EX)",     // Lobe Center Angle EX
    "MaxLift(EX)",     // Max Lift Angle    EX
    "LiftMax(EX)"      // 最大リフト量 mm   EX
};

char main_values[17][16] = {
    "0",        // RPM
    "0.00",     // Angle
    "0.00",     // Linear
    "0.00",     // Lift -
    "0.00",     // BTDC
    "0.00",     // ABDC
    "0.00",     // BBDC
    "0.00",     // ATDC
    "0.00",     // Dura.IN
    "0.00",     // Dura.EX
    "0.00",     // Overlap
    "0.00",     // Lobe Center(IN)
    "0.00",     // MaxLiftAngle(IN)
    "0.00",     // LiftMax(IN)
    "0.00",     // Lobe Center(EX)
    "0.00",     // MaxLiftAngle(EX)
    "0.00"      // LiftMax(EX)
};

// 確定した Lift（Dura.at）の文字列を記憶しておくためのバッファを1つ追加
char confirmed_lift_str[10] = "0.00"; // ★確定したLift値を保持するバッファ

float last_BTDC_IO = 0.0f;
float last_ATDC_EC = 0.0f;

// Start測定開始時の初期フラグ
bool start_zero_requested = false;

void setup() {
    Serial.begin(115200);

    // ブザー
    init_simple_buzzer();   // 一度だけ
    delay(500);

    // 150ミリ秒間 確実に鳴らす
    play_tone_reliable(150);
    delay(500);    
    // ブザー END

    // 各種モジュールの初期化
    init_menu_options();

    // default（ディフォルト）
    load_settings();    

    init_lcd();
    init_interrupts();
    delay(200);

    // ピン番号は環境に合わせて変更してください（例: A=2, B=15, 角度A=14, 角度B=12, ゲージA=27, ゲージB=26）
    init_encoder(27, 26);           // メニュー設定用(27,26)
    delay(200);

    // load_settingsに移動
    // init_angle_encoder(13, 14);     // 角度計測用(13,14) ALT 2006/05/21 変更 12PINに接続すると、立ち上がらないため（競合?）
    // delay(200);

    init_Linear_Gage(35, 34);       // 小野測器 GS-1730A
    delay(200);

    Serial.println("System Initialized");
    delay(200);
    //load_settings();

    // ★追加：起動時にフラッシュから読み込んだパルス数を計算用変数に反映
    int p_idx = menu_data[4].current_idx;
 
    // ★起動時の初期値を確定バッファに格納しておく
    int initial_lift_idx = menu_data[2].current_idx;
    if(menu_data[2].options[initial_lift_idx] != NULL) {
        snprintf(confirmed_lift_str, sizeof(confirmed_lift_str), "%s", menu_data[2].options[initial_lift_idx]);

    }

    // WiFi_AP CSV data
        SPIFFS.begin(true);   // 初回はフォーマット許可






}

void loop() {
    uint32_t now = millis();

    // ==========================================
    // 0. 変数の定義（loopの先頭に移動してどこからでも見えるようにする）
    // ==========================================
    static int last_encoder_val = 0; // ★ここへ移動しました
    int encoder_val = get_encoder_count();
    int encoder_diff = encoder_val - last_encoder_val;

    // ==========================================
    // 1. リアルタイムデータ計算（常にバックグラウンドで実行）
    // ==========================================
    int current_angle_raw = get_angle_raw_count();
    int current_linear_raw = get_Linear_Gage_count();

    int range_type = menu_data[1].current_idx;
    int rotation_dir = menu_data[3].current_idx;

    // ★ CW/CCW の回転方向反転処理（PINの入れ替えで対応）
    int signed_angle_raw = current_angle_raw;

    // 角度計算（累積パルス方式）
    float pulses = current_pulses_per_rev;          // P/R の設定値
    float deg_per_pulse = 360.0f / pulses;

    // 累積角度（CW/CCW 両対応）
    // float raw_angle_deg = (float)current_angle_raw * deg_per_pulse;
    float raw_angle_deg = (float)signed_angle_raw * deg_per_pulse;

    // ★ range_type に応じて折り返し角度を決める（360と720のみ）
    int wrap_angle = (range_type == 0) ? 360 : 720;

    // ★ 表示角度の折り返し
    float disp_angle = fmod(raw_angle_deg, (float)wrap_angle);
    if (disp_angle < 0) disp_angle += wrap_angle;



    // LCD 表示用バッファへ書き込み
    snprintf(angle_str, sizeof(angle_str), "%.2f", disp_angle);

    calculate_Linear_Gage(current_linear_raw, linear_str);

    if (now - last_rpm_time >= 100) {
        uint32_t duration = now - last_rpm_time;
        calculate_rpm_from_pulses(current_angle_raw, last_angle_raw, duration, rpm_str);
        last_angle_raw = current_angle_raw;
        last_rpm_time = now;
    }

    // strcpy ではなく、文字列バッファのポインタをそのまま代入します（安全かつ高速）
    strncpy(main_values[0] , rpm_str, 15);     // RPM
    strncpy(main_values[1] , angle_str, 15);   // Angle
    strncpy(main_values[2] , linear_str, 15);  // Linear

    // 設定データの「Lift (インデックス2)」で選択されている文字列を取得して代入
    // これにより OPT_SEL で変更した値（例: "1.00"）がメイン画面の Lift 行に反映されます
    // 確定済みの変数を表示させる
    strncpy(main_values[3] , confirmed_lift_str, 15);

    // 残りの固定値（今後計算ロジックを組む部分）
    // strncpy(main_values[4] , "0.00", 15);      // BTDC
    // strncpy(main_values[5] , "0.00", 15);      // ABDC
    // strncpy(main_values[6] , "0.00", 15);      // BBDC
    // strncpy(main_values[7] , "0.00", 15);      // ATDC
    // strncpy(main_values[8] , "0.00", 15);      // Dura.IN (duration Intake)
    // strncpy(main_values[9] , "0.00", 15);      // Dura.EX (duration Exhaust)
    // strncpy(main_values[10] , "0.00", 15);     // Overlap
    // strncpy(main_values[11] , "0.00", 15);     // Lobe Center Angle
    // strncpy(main_values[12] , "0.00", 15);     // Max Lift Angle
    // strncpy(main_values[13] , "0.00", 15);     // Lift Max
    // strncpy(main_values[14] , "0.00", 15);     // Lift Min

    // ==========================================
    // 2. 割り込みボタン処理と状態遷移
    // ==========================================
    if (btnA_pressed) {
        btnA_pressed = false;
        lcd.clear();
        if (current_mode == MAIN) {
            current_mode = MENU_SEL;
            last_encoder_val = get_encoder_count(); // 突入時に同期
        } else {
            current_mode = MAIN;
            save_settings(); 
        }
    }

    if (btnB_pressed) { // MENU_SEL <-> OPT_SEL の切り替え
        btnB_pressed = false;
        if (current_mode == MENU_SEL) {
            current_mode = OPT_SEL;
            last_encoder_val = get_encoder_count(); 

            //Serial.print("現在のカーソル位置は = ");
            //Serial.println(menu_cursor );

        } else if (current_mode == OPT_SEL) {

            // ★ Reset が選ばれて YES の場合は初期化を実行
            if (menu_cursor == 6) { // Reset の項目
                int reset_idx = menu_data[6].current_idx;

                if (reset_idx == 2) { // ALL CLR (ALL Clear) が選ばれた
                    Serial.println("=== RESET EXECUTED ===");

                    // 1. 設定値をデフォルトに戻す
                    handle_default();

                    // 2. Lift の確定値も初期化
                    menu_data[2].current_idx = 100;  // Lift のカーソルを 1.00 にする
                    snprintf(confirmed_lift_str, sizeof(confirmed_lift_str), "1.00");   // Lift の確定値も 1.00 にする

                    // 3. パルス数もデフォルトに戻す（4000）
                    current_pulses_per_rev = atof(menu_data[4].options[ menu_data[4].default_idx ]);

                    // 4. エンコーダーのカウントもリセット(リセット実行で不要 ESP.restart())
                    // delay(200);
                    // reset_angle_encoder_count();
                    // delay(200);
                    // reset_Linear_Gage_count();
                    // delay(200);
                    
                    // 5. フラッシュへ保存
                    save_settings();

                    // ブザー
                    // 150ミリ秒間 確実に鳴らす
                    play_tone_reliable(150);
                                        delay(40);
                    // 150ミリ秒間 確実に鳴らす
                    play_tone_reliable(150);

                    // 6. LCD にリセットメッセージを表示
                    lcd.clear();
                    lcd.setCursor(0, 1);
                    lcd.print("Settings RESET");
                    delay(800);

                    // Reset の選択肢を NO に戻す
                    menu_data[6].current_idx = 0;

                    delay(1000); 
                    ESP.restart(); // リセット実行

                } else if (reset_idx == 1) {    // DATA CLR (Clear Data)
                    // IO,IC,EO,EC,,,,Clear Data
                    for (int i = 4; i <= 16; i++) {
                        strcpy(main_values[i], "0.00");
                    }
                    // ブザー
                    // 150ミリ秒間 確実に鳴らす
                    play_tone_reliable(150);
                    delay(40);

                    // Reset NOに戻す
                    menu_data[6].current_idx = 0;

                }

            }

            // --- MODE の確定処理 ---
            if (menu_cursor == 0) {
                int selected_mode = menu_data[0].current_idx;
                if (selected_mode == 0) {
                    menu_data[1].current_idx = 0;
                    menu_data[4].current_idx = 1;
                } else if (selected_mode == 1) {
                    menu_data[1].current_idx = 1;
                    menu_data[4].current_idx = 1;
                }
            }

            // --- Lift の確定処理 ---
            if (menu_cursor == 2) {
                int selected_lift_idx = menu_data[2].current_idx;
                snprintf(confirmed_lift_str, sizeof(confirmed_lift_str),
                         "%s", menu_data[2].options[selected_lift_idx]);

            }

            // --- 回転方向(CW CCW) の確定処理 ---
            if (menu_cursor == 3) {
                int selected_dir_idx = menu_data[3].current_idx;
                // snprintf(confirmed_lift_str, sizeof(confirmed_dir_str),
                //          "%s", menu_data[3].options[selected_dir_idx]);

                Serial.print("回転方向(CW CCW) の確定処理 : ");
                Serial.println(selected_dir_idx);

                // Setting.cppもあり
                // 設定変更
                if (selected_dir_idx == 0) {
                    // CW
                    init_angle_encoder(13, 14);     // 角度計測用(13,14) ALT 2006/05/21 変更 12PINに接続すると、立ち上がらないため（競合?）

                } else {
                    // CCW
                    init_angle_encoder(14, 13);     // 角度計測用(13,14) ALT 2006/05/21 変更 12PINに接続すると、立ち上がらないため（競合?）
                }
                delay(200);

            }

            // --- P/R の確定処理 ---
            if (menu_cursor == 4) {
                int selected_p_idx = menu_data[4].current_idx;
                current_pulses_per_rev = atof(menu_data[4].options[selected_p_idx]);
            }

            /* --- Start の確定処理 -------------------------
            1.Start にカーソルがある (menu_cursor == 5) ＋ btnC が押された  
                → フラグを立てる（例：start_zero_requested = true）
            2.その後、Intake / Exhaust を選ぶ（menu_data[5].current_idx）＋ btnB を押す
                ★start_zero_requested == true の場合
                    → 選ばれた側（Intake / Exhaust）が 0スタート（0〜3999に記録）
                ★start_zero_requested == false の場合
                    → 選ばれた側が 4000スタート（4000〜7999に記録）
            3.測定開始後はフラグをクリア  
                → start_zero_requested = false;
            つまり：
            Intake を先に測れば Intake が 0〜3999
            Exhaust を先に測れば Exhaust が 0〜3999
            どちらも 同じ基準（0°）から測定されるので、
            相関は絶対にズレません。
            ------------------------------------------------*/
            if (menu_cursor == 5) {

            // Serial.print("カーソルは Start の行にあります = ");
            // Serial.println(menu_cursor);

                int start_idx  = menu_data[5].current_idx;  // 0=Intake, 1=Exhaust
                int range_type = menu_data[1].current_idx;
                int ppr_idx    = menu_data[4].current_idx;

                // 測定開始
                cam_analyzer_start(start_idx, range_type, ppr_idx, start_zero_requested);
                
                // ★ 測定開始後はフラグをクリア
                start_zero_requested = false;  // 使い終わったらクリア
                
            }
            
            current_mode = MENU_SEL;    // 状態を戻す
            save_settings();            // 設定を保存
        }

    }

    if (btnC_pressed) {
        btnC_pressed = false;

        reset_angle_encoder_count();  // 常にリセット

        // Start にカーソルがあるときだけ「次の測定は 0スタート」
        if (menu_cursor == 5) {       // Start にカーソルがあるときだけフラグON
            start_zero_requested = true;
            Serial.println("Start Zero Requested");
        }
    }

    // Linear_Gage Zero
    if (btnD_pressed) { btnD_pressed = false; reset_Linear_Gage_count(); }
    
    // CSV Dounload Wi_Fi AP Mode
    if (btnE_pressed) {
        btnE_pressed = false;

    play_tone_reliable(150);    // 起動音

        if (!wifi_is_active()) {
            wifi_start_ap();
            play_tone_reliable(150);    // 起動音
            delay(100);    
            play_tone_reliable(150);    // 起動音
        }

    }

    if (btnF_pressed) btnF_pressed = false;

    // ==========================================
    // 3. エンコーダー入力によるカーソル・値の変更
    // ==========================================
    // (※ここでは static int last_encoder_val = 0; の行を削除してください。先頭にあるため)

    if (current_mode == MAIN) {
        if (abs(encoder_diff) >= 4) {

            const int total_items = 17;  // main_labels の数
            const int view_lines  = 4;   // 表示行数
            const int max_offset  = total_items - view_lines; // = 13

            main_scroll_offset += (encoder_diff > 0) ? 1 : -1;

            if (main_scroll_offset < 0) main_scroll_offset = 0;
            if (main_scroll_offset > max_offset) main_scroll_offset = max_offset;

            last_encoder_val = encoder_val;
        }
    }

    else if (current_mode == MENU_SEL) {
        if (abs(encoder_diff) >= 4) {

            menu_cursor += (encoder_diff > 0) ? 1 : -1;

            if (menu_cursor < 0) menu_cursor = 0;
            if (menu_cursor >= MENU_COUNT) menu_cursor = MENU_COUNT - 1;

            last_encoder_val = encoder_val;
        }
    }

    else if (current_mode == OPT_SEL) {
        if (abs(encoder_diff) >= 4) {

            int dir = (encoder_diff > 0) ? 1 : -1;
            MenuEntry* current_menu = &menu_data[menu_cursor];

            // Lift の高速スクロール
            if (menu_cursor == 2 && abs(encoder_diff) >= 12) {
                dir *= 10;
            }

            current_menu->current_idx += dir;

            if (current_menu->current_idx < 0)
                current_menu->current_idx = 0;

            if (current_menu->current_idx >= current_menu->opt_count)
                current_menu->current_idx = current_menu->opt_count - 1;

            last_encoder_val = encoder_val;
        }
    }

    if (encoder_val != last_encoder_val &&
        (current_mode != MAIN && current_mode != MENU_SEL && current_mode != OPT_SEL)) {
        last_encoder_val = encoder_val;
    }
    // 各モードの「if文」に引っかからなかった場合でも、
    // エンコーダーが回されたら常に最新の値を追いかけるように同期させる
    // これにより、モードを切り替えた瞬間に画面が勝手にスクロールするのを防ぎます
    if (encoder_val != last_encoder_val && current_mode != MAIN && current_mode != MENU_SEL && current_mode != OPT_SEL) {
        last_encoder_val = encoder_val;
    }

    // ==========================================
    // 4. 画面描画（リフレッシュレートの制御）
    // ==========================================
    static uint32_t last_screen_time = 0;
    if (now - last_screen_time >= 50) { // 50msごとに画面書き換え
        last_screen_time = now;

        if (current_mode == MAIN) {
            // 一時配列を一切使わず、main_valuesをそのまま渡す
            // これによりメモリ破壊や不正アクセスは物理的に発生しなくなります
            display_main_screen(main_scroll_offset, main_labels, main_values);
        } else {
            // 設定画面の表示
            int display_mode = (current_mode == MENU_SEL) ? 1 : 2;
            display_setting_screen(menu_cursor, display_mode, menu_data);
        }
    } 
    
    // ★★★ WiFi WebServer を動かす（必ず最後） ★★★
    wifi_loop();

}
