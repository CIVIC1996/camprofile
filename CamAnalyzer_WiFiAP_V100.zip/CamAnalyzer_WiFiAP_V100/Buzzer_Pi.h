/*
 * @file    Buzzer_Pi.h
 * @author  yoshio ide
 * @brief   設定
 * @date    2026/07/20
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#pragma once
#include <Arduino.h>

void init_simple_buzzer();

void play_tone_reliable(uint32_t duration_ms);




