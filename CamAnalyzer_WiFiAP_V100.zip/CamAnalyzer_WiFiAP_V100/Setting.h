/*
 * @file    Setting.h
 * @author  yoshio ide
 * @brief   設定
 * @date    2026-05-01
 * Copyright (c) 2026 [yoshio ide]
 * All rights reserved.
 */

#pragma once


struct MenuEntry {
    const char* label;
    const char* options[155]; // 151個より少し多めにバッファを確保してメモリ破壊を防ぐ
    int opt_count;
    int current_idx;
    int default_idx;
};

extern MenuEntry menu_data[];
extern const int MENU_COUNT;
void init_menu_options(); // 選択肢を動的に生成する関数を追加
void handle_default();
void load_settings();
void save_settings();
